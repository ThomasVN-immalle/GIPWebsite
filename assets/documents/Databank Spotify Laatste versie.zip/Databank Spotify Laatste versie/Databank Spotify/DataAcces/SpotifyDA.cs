﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Business;
using MySql.Data.MySqlClient;

namespace DataAccess
{
    public class SpotifyDA
    {

            private string _connString;
            private MySqlConnection _mySqlConnection;

            public SpotifyDA()
            {
                _connString = "server=localhost; user id=root; Password=admin; database=mydb";
                _mySqlConnection = new MySqlConnection(_connString);
            }

            public List<Klant> ReadTable()
            {
                List<Klant> lijst = new List<Klant>();

                string sql = "SELECT * FROM klanten ORDER BY naam;";

                MySqlCommand mySqlCommand = new MySqlCommand(sql, _mySqlConnection);

                _mySqlConnection.Open();

                MySqlDataReader mySqlDataReader = mySqlCommand.ExecuteReader();

                while (mySqlDataReader.Read() == true)
                {

                Klant Klant = new Klant(
                (int)(mySqlDataReader["KlantId"]),
                mySqlDataReader["Voornaam"].ToString(),
                (mySqlDataReader["Achternaam"]).ToString(),
                (mySqlDataReader["Geboortedatum"]).ToString(),
                mySqlDataReader["Emailadres"].ToString(),
                (mySqlDataReader["Factuurdatum"]).ToString());

                    lijst.Add(Klant);
                }

                _mySqlConnection.Close();

                return lijst;

            }

            public void UpdateRecord(Klant Klant)
            {
                string sql = "UPDATE klanten SET Voornaam = @Voornaam," +
                "Familienaam = @Familienaam, Geboortedatum = @Geboortedatum," +
                "Emailadres = @Emailadres, Factuurdatum = @Factuurdatum,"
                + "WHERE (id = @ID);";

                MySqlCommand mySqlCommand = new MySqlCommand(sql, _mySqlConnection);

                mySqlCommand.Parameters.AddWithValue("@Voornaam", Klant.Voornaam);
                mySqlCommand.Parameters.AddWithValue("@Familienaam", Klant.Familienaam);
                mySqlCommand.Parameters.AddWithValue("@Geboortedatum", Klant.Geboortedatum);
                mySqlCommand.Parameters.AddWithValue("@Emailadres", Klant.Emailadres);
                mySqlCommand.Parameters.AddWithValue("@Factuurdatum", Klant.Factuurdatum);
                mySqlCommand.Parameters.AddWithValue("@KlantID", Klant.KlantId);

                _mySqlConnection.Open();

                mySqlCommand.ExecuteNonQuery();

                _mySqlConnection.Close();
            }

        public void CreateRecord(Klant klant)
        {
            string sql = "INSERT INTO klanten(Voornaam,Familienaam,Geboortedatum,Emailadres,Factuurdatum,KlantID)" +
                         "VALUES(@Voornaam,@Familienaam,@Geboortedatum,@Emailadres,@Factuurdatum,@KlantID);";

            MySqlCommand mySqlCommand = new MySqlCommand(sql, _mySqlConnection);

            mySqlCommand.Parameters.AddWithValue("@Voornaam", klant.Voornaam);
            mySqlCommand.Parameters.AddWithValue("@Familienaam",klant.Familienaam);
            mySqlCommand.Parameters.AddWithValue("@Geboortedatum", klant.Geboortedatum);
            mySqlCommand.Parameters.AddWithValue("@Emailadres", klant.Emailadres);
            mySqlCommand.Parameters.AddWithValue("@Factuurdatum", klant.Factuurdatum);
            mySqlCommand.Parameters.AddWithValue("@KlantID", klant.KlantId);

            _mySqlConnection.Open();

            mySqlCommand.ExecuteNonQuery();

            _mySqlConnection.Close();
        }

    }
    }

