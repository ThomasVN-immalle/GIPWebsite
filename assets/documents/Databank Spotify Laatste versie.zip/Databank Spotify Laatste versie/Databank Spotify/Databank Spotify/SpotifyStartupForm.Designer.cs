﻿
namespace Presentation
{
    partial class SpotifyStartupForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.SpotifyKlantListbox = new System.Windows.Forms.ListBox();
            this.ToonButton = new System.Windows.Forms.Button();
            this.NieuwButton = new System.Windows.Forms.Button();
            this.VerwijderButton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // SpotifyKlantListbox
            // 
            this.SpotifyKlantListbox.FormattingEnabled = true;
            this.SpotifyKlantListbox.ItemHeight = 16;
            this.SpotifyKlantListbox.Location = new System.Drawing.Point(68, 89);
            this.SpotifyKlantListbox.Name = "SpotifyKlantListbox";
            this.SpotifyKlantListbox.Size = new System.Drawing.Size(667, 244);
            this.SpotifyKlantListbox.TabIndex = 0;
            // 
            // ToonButton
            // 
            this.ToonButton.Location = new System.Drawing.Point(101, 359);
            this.ToonButton.Name = "ToonButton";
            this.ToonButton.Size = new System.Drawing.Size(109, 50);
            this.ToonButton.TabIndex = 2;
            this.ToonButton.Text = "Toon";
            this.ToonButton.UseVisualStyleBackColor = true;
            // 
            // NieuwButton
            // 
            this.NieuwButton.Location = new System.Drawing.Point(352, 359);
            this.NieuwButton.Name = "NieuwButton";
            this.NieuwButton.Size = new System.Drawing.Size(109, 50);
            this.NieuwButton.TabIndex = 3;
            this.NieuwButton.Text = "Nieuw";
            this.NieuwButton.UseVisualStyleBackColor = true;
            // 
            // VerwijderButton
            // 
            this.VerwijderButton.Location = new System.Drawing.Point(589, 359);
            this.VerwijderButton.Name = "VerwijderButton";
            this.VerwijderButton.Size = new System.Drawing.Size(109, 50);
            this.VerwijderButton.TabIndex = 4;
            this.VerwijderButton.Text = "Verwijder";
            this.VerwijderButton.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Showcard Gothic", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(319, 34);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(188, 50);
            this.label1.TabIndex = 5;
            this.label1.Text = "Spotify";
            // 
            // SpotifyStartupForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.SpringGreen;
            this.ClientSize = new System.Drawing.Size(788, 441);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.VerwijderButton);
            this.Controls.Add(this.NieuwButton);
            this.Controls.Add(this.ToonButton);
            this.Controls.Add(this.SpotifyKlantListbox);
            this.Name = "SpotifyStartupForm";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox SpotifyKlantListbox;
        private System.Windows.Forms.Button ToonButton;
        private System.Windows.Forms.Button NieuwButton;
        private System.Windows.Forms.Button VerwijderButton;
        private System.Windows.Forms.Label label1;
    }
}

