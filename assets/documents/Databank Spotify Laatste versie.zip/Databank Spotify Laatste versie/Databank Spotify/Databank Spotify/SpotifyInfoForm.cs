﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Business;

namespace Databank_Spotify
{
    public partial class SpotifyInfoForm : Form
    {
        private Klant _klant;
        public SpotifyInfoForm(Klant klant)
        {
            InitializeComponent();

            _klant = klant;
            Details.Text = _klant.KlantId.ToString();
            Details.Text = _klant.AbonnementID.ToString();
            Details.Text = _klant.Voornaam;
            Details.Text = _klant.Familienaam;
            Details.Text = _klant.Geboortedatum.ToString();
            Details.Text = _klant.Emailadres;
            Details.Text = _klant.Factuurdatum.ToString();
        }

        private void Details_SelectedIndexChanged(object sender, EventArgs e)
        {
         
        }

        private void button1_Click(object sender, EventArgs e)
        {
            _klant.AbonnementID = Convert.ToInt32(Details.Text);
            _klant.Voornaam = Details.Text;
            _klant.Familienaam = Details.Text;
            _klant.Geboortedatum = Details.Text;
            _klant.Emailadres = Details.Text;
            _klant.Factuurdatum = Details.Text;

            Close();
        }
    }
}

