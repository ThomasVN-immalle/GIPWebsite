﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Business;
using DataAccess;
using Databank_Spotify;

namespace Presentation
{
    public partial class SpotifyStartupForm : Form
    {

        private List<Klant> _spotifyLijst;
        private SpotifyDA _spotifyDA = new SpotifyDA();

        public SpotifyStartupForm()
        {
            InitializeComponent();

            _spotifyLijst = new List<Klant>();

            _spotifyLijst = _spotifyDA.ReadTable();

            SpotifyKlantListbox.DataSource = _spotifyLijst;
        }

        private void toonButton_Click(object sender, EventArgs e)
        {
            Klant klant = (Klant)SpotifyKlantListbox.SelectedItem;

            SpotifyInfoForm formulier = new SpotifyInfoForm(klant);
            formulier.ShowDialog();

            _spotifyDA.UpdateRecord(klant);

            SpotifyKlantListbox.DataSource = null;
            SpotifyKlantListbox.DataSource = _spotifyLijst;
        }

        private void nieuwButton_Click(object sender, EventArgs e)
        {

            int maxID = _spotifyLijst.Max(x => x.KlantId);

            Klant klant = new Klant(maxID+1,"", "", "", "", "");

            _spotifyLijst.Add(klant);

            SpotifyInfoForm formulier =  new SpotifyInfoForm(klant);
            formulier.ShowDialog();


            _spotifyDA.CreateRecord(klant);

            _spotifyLijst = _spotifyDA.ReadTable();

        }
        private void verwijderButton_Click(object sender, EventArgs e)
        {
            Klant klant = (Klant)SpotifyKlantListbox.SelectedItem;
        
            _spotifyLijst.Remove(klant);

            SpotifyKlantListbox.DataSource = null;
            SpotifyKlantListbox.DataSource = _spotifyLijst;
        }
    }
}

